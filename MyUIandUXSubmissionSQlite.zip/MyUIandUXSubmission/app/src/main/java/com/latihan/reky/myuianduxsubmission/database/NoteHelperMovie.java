package com.latihan.reky.myuianduxsubmission.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.latihan.reky.myuianduxsubmission.favorite.NoteMovie;

import static android.provider.BaseColumns._ID;
import static com.latihan.reky.myuianduxsubmission.database.DatabaseContractMovie.DatabaseMovie.TABLE_NAME;
import static com.latihan.reky.myuianduxsubmission.database.DatabaseContractMovie.DatabaseMovie.COLUMN_IMAGE;
import static com.latihan.reky.myuianduxsubmission.database.DatabaseContractMovie.DatabaseMovie.COLUMN_TITLE;
import static com.latihan.reky.myuianduxsubmission.database.DatabaseContractMovie.DatabaseMovie.COLUMN_DESC;


public class NoteHelperMovie {

    public static final String DATABASE_TABLE = TABLE_NAME;
    private static DatabaseHelperMovie databaseHelperMovie;
    private static NoteHelperMovie INSTANCE;

    private static SQLiteDatabase databaseMovie;

    private NoteHelperMovie (Context context) {
        databaseHelperMovie = new DatabaseHelperMovie(context);
    }

    public static NoteHelperMovie getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SQLiteOpenHelper.class) {
                if (INSTANCE == null) {
                    INSTANCE = new NoteHelperMovie(context);
                }
            }
        }
        return INSTANCE;
    }

    public void open() throws SQLException {
        databaseMovie = databaseHelperMovie.getWritableDatabase();
    }

    public void close() {
        databaseHelperMovie.close();

        if (databaseMovie.isOpen())
            databaseMovie.close();

    }

    public Cursor queryAll() {
        return databaseMovie.query(
                DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null,
                _ID + " ASC");
    }

    public Cursor queryById(String id) {
        return databaseMovie.query(DATABASE_TABLE, null
        , _ID + " = ?"
        , new String[]{id}
        ,null
        , null
        ,null
        ,null);
    }

    public long insert(NoteMovie noteMovie) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_IMAGE, noteMovie.getImageFav());
        values.put(COLUMN_TITLE, noteMovie.getTitle());
        values.put(COLUMN_DESC, noteMovie.getDescription());

        return databaseMovie.insert(DATABASE_TABLE, null, values);
    }

    public int uodate(String id, ContentValues values) {
        return databaseMovie.update(DATABASE_TABLE, values, _ID +" = ?", new String[]{id});
    }

    public int deleteById(String id) {
        return databaseMovie.delete(DATABASE_TABLE, _ID + " = ?", new String[]{id});
    }
}
