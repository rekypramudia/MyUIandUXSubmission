package com.latihan.reky.myuianduxsubmission;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;


import com.squareup.picasso.Picasso;
import com.squareup.picasso.Request;

import java.util.ArrayList;
import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private Context mContext;
    private List<Movie> listMovie;


    MovieAdapter(Context mContext,List<Movie> listMovie) {
        this.mContext = mContext;
        this.listMovie = listMovie;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull final ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.movie_item, viewGroup,false);
        final MovieViewHolder movieViewHolder = new MovieViewHolder(view);
        movieViewHolder.itemMovieDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailActivityMovie = new Intent(mContext, DetailActivityMovie.class);
                detailActivityMovie.putExtra("movie_img",listMovie.get(movieViewHolder.getAdapterPosition()).getImgPhoto());
                detailActivityMovie.putExtra("movie_title",listMovie.get(movieViewHolder.getAdapterPosition()).getTxtTitle());
                detailActivityMovie.putExtra("movie_desc",listMovie.get(movieViewHolder.getAdapterPosition()).getTxtDesc());

                mContext.startActivity(detailActivityMovie);


            }
        });


        return movieViewHolder;

    }

    @Override
    public void onBindViewHolder (MovieViewHolder holder,int position) {
      Movie movieItem = listMovie.get(position);


        String imageMovie = movieItem.getImgPhoto();
        String titleMovie = movieItem.getTxtTitle();
        String descMovie = movieItem.getTxtDesc();
       /* holder.imgMovie.setImageResource(listMovie.get(position).getImgPhoto());*/
      /* Glide.with(mContext).load(imageMovie)
               .apply(new RequestOptions().override(70,70))
               .into(holder.imgMovie);*/

        Picasso.get().load("https://image.tmdb.org/t/p/w780"+ imageMovie)
                .fit().centerInside()
                .into(holder.imgMovie);
        holder.tittleText.setText(titleMovie);
        holder.descText.setText(descMovie);


        /*holder.itemMovieDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent detailActivityMovie = new Intent(mContext,DetailActivityMovie.class);
                detailActivityMovie.putExtra(DetailActivityMovie.EXTRA_MOVIE, listMovie.get(position));
                mContext.startActivity(detailActivityMovie);
            }
        });*/

    }


    @Override
    public int getItemCount() {
        return listMovie.size();
    }

    void setListMovie(List<Movie> listMovie) {
        this.listMovie = listMovie;
        notifyDataSetChanged();
    }

    static class MovieViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout itemMovieDetail;
        ImageView imgMovie;
        TextView tittleText;
        TextView descText;
        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            itemMovieDetail = itemView.findViewById(R.id.movie_detail);
            imgMovie =  itemView.findViewById(R.id.img_item_photo);
            tittleText = itemView.findViewById(R.id.tv_title_movie);
            descText = itemView.findViewById(R.id.tv_description_movie);



        }
    }
}
