package com.latihan.reky.myuianduxsubmission;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.latihan.reky.myuianduxsubmission.database.NoteHelperMovie;
import com.latihan.reky.myuianduxsubmission.favorite.NoteMovie;
import com.squareup.picasso.Picasso;

import java.util.Objects;


public class DetailActivityMovie extends AppCompatActivity implements View.OnClickListener {

    private ProgressBar progressBar;
    private NoteHelperMovie noteHelperMovie;
    public static final String EXTRA_MOVIE_TO_FAVORITE = "extra_movie_favorite";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        progressBar = findViewById(R.id.progressBarMovie);

        String imageMovie = Objects.requireNonNull(getIntent().getExtras()).getString("movie_img");
        String titleMovie = getIntent().getExtras().getString("movie_title");
        String descMovie = getIntent().getExtras().getString("movie_desc");

        ImageView imageView = findViewById(R.id.img_movie_detail);
        TextView titleMovieDetail = findViewById(R.id.tv_detail_title_movie);
        TextView descMovieDetail = findViewById(R.id.tv_detail_desc_movie);

        NoteMovie addMovieToFav = getIntent().getParcelableExtra(EXTRA_MOVIE_TO_FAVORITE);
        String movieItem = Integer.toString(addMovieToFav.getId());

        noteHelperMovie = NoteHelperMovie.getInstance(getApplicationContext());
        noteHelperMovie.open();

        

        progressBar.setVisibility(View.VISIBLE);

        Picasso.get().load("https://image.tmdb.org/t/p/w780"+ imageMovie)
                .fit().centerInside()
                .into(imageView, new com.squareup.picasso.Callback(){

                    @Override
                    public void onSuccess() {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onError(Exception e) {
                        e.printStackTrace();

                    }
                });
        titleMovieDetail.setText(titleMovie);
        descMovieDetail.setText(descMovie);

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setElevation(0);
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_favorite, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_love:
                break;
            case android.R.id.home:
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.action_love) {
            NoteMovie addMovieToFav = getIntent().getParcelableExtra(EXTRA_MOVIE_TO_FAVORITE);
            long result = noteHelperMovie.insert(addMovieToFav);
            if (result > 0) {
                Toast.makeText(this, "Berhasil ditambahkan ke Favorite", Toast.LENGTH_SHORT).show();


            } else {
                Toast.makeText(this, "Gagal ditambahkan ke Favorite", Toast.LENGTH_SHORT).show();
            }

        }
    }



}
