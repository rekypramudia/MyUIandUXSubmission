package com.latihan.reky.myuianduxsubmission;


public class Movie {

    private String imgPhoto;
    private String txtTitle;
    private String txtDesc;

    public Movie () {

    }

    Movie(String imgPhoto, String txtTitle, String txtDesc) {
        this.imgPhoto = imgPhoto;
        this.txtTitle = txtTitle;
        this.txtDesc = txtDesc;
    }



    String getImgPhoto() {
        return imgPhoto;
    }

    public void setImgPhoto(String imgPhoto) {
        this.imgPhoto = imgPhoto;
    }

    String getTxtTitle() {
        return txtTitle;
    }

    public void setTxtTitle(String txtTitle) {
        this.txtTitle = txtTitle;
    }

    String getTxtDesc() {
        return txtDesc;
    }

    public void setTxtDesc(String txtDesc) {
        this.txtDesc = txtDesc;
    }


}
