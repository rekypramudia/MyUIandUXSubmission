package com.latihan.reky.myuianduxsubmission.favorite;

import android.os.Parcel;
import android.os.Parcelable;

public class NoteMovie implements Parcelable {
    private int id;
    private String imageFav;
    private String title;
    private String description;

    public NoteMovie() {}

    public NoteMovie(int id, String imageFav, String title, String description) {
        this.id = id;
        this.imageFav = imageFav;
        this.title = title;
        this.description = description;
    }

    protected NoteMovie(Parcel in) {
        id = in.readInt();
        imageFav = in.readString();
        title = in.readString();
        description = in.readString();
    }

    public static final Creator<NoteMovie> CREATOR = new Creator<NoteMovie>() {
        @Override
        public NoteMovie createFromParcel(Parcel in) {
            return new NoteMovie(in);
        }

        @Override
        public NoteMovie[] newArray(int size) {
            return new NoteMovie[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImageFav() {
        return imageFav;
    }

    public void setImageFav(String imageFav) {
        this.imageFav = imageFav;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(imageFav);
        dest.writeString(title);
        dest.writeString(description);
    }
}
