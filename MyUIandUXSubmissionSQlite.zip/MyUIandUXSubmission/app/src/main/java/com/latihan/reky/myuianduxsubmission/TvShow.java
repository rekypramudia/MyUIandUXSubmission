package com.latihan.reky.myuianduxsubmission;


public class TvShow {

    private String titleName;
    private String descName;
    private String imgTv;

    public TvShow() {

    }

    TvShow(String titleName, String descName, String imgTv) {
        this.titleName = titleName;
        this.descName = descName;
        this.imgTv = imgTv;

    }

    String getTitleName() {
        return titleName;
    }

    public void setTitleName(String titleName) {
        this.titleName = titleName;
    }

    String getDescName() {
        return descName;
    }

    public void setDescName(String descName) {
        this.descName = descName;
    }

    String getImgTv() {
        return imgTv;
    }

    public void setImgTv(String imgTv) {
        this.imgTv = imgTv;
    }

}
