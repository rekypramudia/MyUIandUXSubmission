package com.latihan.reky.myuianduxsubmission;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

public class TvShowViewModel extends ViewModel {
    private MutableLiveData<List<TvShow>> listShow;


    public TvShowViewModel(MutableLiveData<List<TvShow>> listShow) {
        this.listShow = listShow;
    }

    void getDataShow() {
        final List<TvShow> movieFromNetwork = new ArrayList<>();
        String JSON_URL = "https://api.themoviedb.org/3/discover/tv?api_key=5db7d5b8c75b4e604d6156764ae2d513&language=en-US";
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(JSON_URL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String resultShow = new String(responseBody);
                    JSONObject tvShowObject = new JSONObject(resultShow);
                    JSONArray list = tvShowObject.getJSONArray("results");

                    for (int i = 0; i < list.length(); i++) {
                        JSONObject result = list.getJSONObject(i);
                        String titleTv = result.getString("name");
                        String overviewTv = result.getString("overview");
                        String imageTv = result.getString("poster_path");

                        movieFromNetwork.add(new TvShow(titleTv,overviewTv,imageTv));

                        listShow.postValue(movieFromNetwork);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d(error.getMessage(), "onFailure");
            }
        });

    }

    LiveData<List<TvShow>> setData(){
        return listShow;
    }
}

