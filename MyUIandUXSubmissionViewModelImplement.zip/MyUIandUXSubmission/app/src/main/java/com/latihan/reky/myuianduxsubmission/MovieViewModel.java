package com.latihan.reky.myuianduxsubmission;

import android.util.Log;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;

class MovieViewModel extends ViewModel {
    private MutableLiveData<List<Movie>> listMovie;

    MovieViewModel(MutableLiveData<List<Movie>> listMovie) {
        this.listMovie = listMovie;
    }

    void getDataMovie() {
        final List<Movie> movieFromNetwork = new ArrayList<>();
        String JSON_URL = "https://api.themoviedb.org/3/discover/movie?api_key=5db7d5b8c75b4e604d6156764ae2d513&language=en-US";
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(JSON_URL, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                try {
                    String resultMovie = new String(responseBody);
                    JSONObject movieObject = new JSONObject(resultMovie);
                    JSONArray list = movieObject.getJSONArray("results");

                    for (int i = 0; i < list.length(); i++) {
                        JSONObject result = list.getJSONObject(i);
                        String imageMovie = result.getString("poster_path");
                        String titleMovie = result.getString("title");
                        String overviewMovie = result.getString("overview");
                        movieFromNetwork.add(new Movie(imageMovie, titleMovie, overviewMovie));

                        listMovie.postValue(movieFromNetwork);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                Log.d(error.getMessage(), "onFailure");
            }
        });

    }

    LiveData<List<Movie>> setData(){
        return listMovie;
    }

}
