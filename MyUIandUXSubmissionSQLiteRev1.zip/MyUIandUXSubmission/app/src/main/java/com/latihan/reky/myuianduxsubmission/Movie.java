package com.latihan.reky.myuianduxsubmission;


import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {

    private String imgPhoto;
    private String txtTitle;
    private String txtDesc;

    public Movie () {

    }

    Movie(String imgPhoto, String txtTitle, String txtDesc) {
        this.imgPhoto = imgPhoto;
        this.txtTitle = txtTitle;
        this.txtDesc = txtDesc;
    }


    protected Movie(Parcel in) {
        imgPhoto = in.readString();
        txtTitle = in.readString();
        txtDesc = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    String getImgPhoto() {
        return imgPhoto;
    }

    public void setImgPhoto(String imgPhoto) {
        this.imgPhoto = imgPhoto;
    }

    String getTxtTitle() {
        return txtTitle;
    }

    public void setTxtTitle(String txtTitle) {
        this.txtTitle = txtTitle;
    }

    String getTxtDesc() {
        return txtDesc;
    }

    public void setTxtDesc(String txtDesc) {
        this.txtDesc = txtDesc;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(imgPhoto);
        dest.writeString(txtTitle);
        dest.writeString(txtDesc);
    }
}
