package com.latihan.reky.myuianduxsubmission.favorite;

import android.os.Parcel;
import android.os.Parcelable;

public class NoteTv implements Parcelable {
    private int id;
    private String titleNameFav;
    private String descNameFav;
    private String imgTvFav;

    public NoteTv(){}

    public NoteTv(int id, String titleNameFav, String descNameFav, String imgTvFav) {
        this.id = id;
        this.titleNameFav = titleNameFav;
        this.descNameFav = descNameFav;
        this.imgTvFav = imgTvFav;
    }

    protected NoteTv(Parcel in) {
        id = in.readInt();
        titleNameFav = in.readString();
        descNameFav = in.readString();
        imgTvFav = in.readString();
    }

    public static final Creator<NoteTv> CREATOR = new Creator<NoteTv>() {
        @Override
        public NoteTv createFromParcel(Parcel in) {
            return new NoteTv(in);
        }

        @Override
        public NoteTv[] newArray(int size) {
            return new NoteTv[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitleNameFav() {
        return titleNameFav;
    }

    public void setTitleNameFav(String titleNameFav) {
        this.titleNameFav = titleNameFav;
    }

    public String getDescNameFav() {
        return descNameFav;
    }

    public void setDescNameFav(String descNameFav) {
        this.descNameFav = descNameFav;
    }

    public String getImgTvFav() {
        return imgTvFav;
    }

    public void setImgTvFav(String imgTvFav) {
        this.imgTvFav = imgTvFav;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(titleNameFav);
        dest.writeString(descNameFav);
        dest.writeString(imgTvFav);
    }
}
