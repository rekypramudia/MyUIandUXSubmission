package com.latihan.reky.myuianduxsubmission.database;


import android.database.Cursor;


import com.latihan.reky.myuianduxsubmission.favorite.NoteMovie;

import java.util.ArrayList;

public class MappingHelperMovie {


    public static ArrayList<NoteMovie> mapCursorToArrayList(Cursor moviesCursor) {
        ArrayList<NoteMovie> moviesList = new ArrayList<>();

        while (moviesCursor.moveToNext()) {
            int id = moviesCursor.getInt(moviesCursor.getColumnIndexOrThrow(DatabaseContractMovie.DatabaseMovie._ID));
            String imageMovie = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContractMovie.DatabaseMovie.COLUMN_IMAGE));
            String titleMovie = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContractMovie.DatabaseMovie.COLUMN_TITLE));
            String descMovie = moviesCursor.getString(moviesCursor.getColumnIndexOrThrow(DatabaseContractMovie.DatabaseMovie.COLUMN_DESC));
            moviesList.add(new NoteMovie(id, imageMovie, titleMovie, descMovie));

        }
        return moviesList;
    }

}
