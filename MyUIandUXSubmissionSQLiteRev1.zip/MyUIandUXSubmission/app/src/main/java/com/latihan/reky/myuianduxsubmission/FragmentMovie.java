package com.latihan.reky.myuianduxsubmission;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;


public class FragmentMovie extends Fragment {

    private ProgressDialog progressDialog;
    private MovieAdapter movieAdapter;
    public FragmentMovie() { }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.movies_fragment, container, false);
        RecyclerView rvMovies = view.findViewById(R.id.movie_rv);
        rvMovies.setLayoutManager(new LinearLayoutManager(getActivity()));
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Loading....");
        movieAdapter = new MovieAdapter(requireContext(), new ArrayList<Movie>());
        rvMovies.setAdapter(movieAdapter);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        MovieViewModel movieViewModel = new ViewModelProvider(this).get(MovieViewModel.class);
        movieViewModel.setData().observe(getViewLifecycleOwner(), new Observer<List<Movie>>() {
            @Override
            public void onChanged(List<Movie> movies) {
                movieAdapter.setListMovie(movies);
            }
        });
        movieViewModel.getLoading().observe(getViewLifecycleOwner(), new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                if(aBoolean){
                    progressDialog.show();
                } else {
                    progressDialog.dismiss();
                }
            }
        });
        movieViewModel.getDataMovie(requireContext());
    }
}











   /* @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);*/



       /* listMovie = new ArrayList<>();
        listMovie.add(new Movie(R.drawable.poster_a_start_is_born,"A Star is Born","Seasoned musician Jackson Maine discovers — and falls in love with — struggling artist Ally. She has just about given up on her dream to make it big as a singer — until Jack coaxes her into the spotlight. But even as Ally's career takes off, the personal side of their relationship is breaking down, as Jack fights an ongoing battle with his own internal demons"));
        listMovie.add(new Movie(R.drawable.poster_alita,"Alita Battle Angel","In 2563, 300 years after Earth was devastated by a catastrophic war known as \"The Fall,” scientist Dr. Dyson Ido discovers a disembodied female cyborg with an intact human brain while scavenging for parts in the massive scrapyard of Iron City. Ido attaches a new cyborg body to the brain and names her \"Alita\" after his deceased daughter"));
        listMovie.add(new Movie(R.drawable.poster_aquaman,"Aquaman","Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne"));
        listMovie.add(new Movie(R.drawable.poster_bohemian,"Bohemian Rhapsody","Singer Freddie Mercury, guitarist Brian May, drummer Roger Taylor and bass guitarist John Deacon take the music world by storm when they form the rock 'n' roll band Queen in 1970. Hit songs become instant classics. When Mercury's increasingly wild lifestyle starts to spiral out of control, Queen soon faces its greatest challenge yet – finding a way to keep the band together amid the success and excess"));
        listMovie.add(new Movie(R.drawable.poster_spiderman,"Spiderman Into The Spider_Verse","Miles returns to the station to search for the spider and discovers a particle accelerator called \"The Super-Collider\" built by Kingpin, who hopes to access parallel universes and reunite with his dead family. Spider-Man is fighting Kingpin's enforcers, Green Goblin and Prowler"));
        listMovie.add(new Movie(R.drawable.poster_creed,"Creed","The former World Heavyweight Champion Rocky Balboa serves as a trainer and mentor to Adonis Johnson, the son of his late friend and former rival Apollo Creed"));
        listMovie.add(new Movie(R.drawable.poster_glass,"Glass","David and Kevin are placed into separate rooms that contain unique security measures based on their specific weaknesses. Staple explains that she believes they suffer from delusions of grandeur and do not have superpowers. Elijah's mother Mrs. Price, Joseph Dunn and Casey Cooke, a victim who survived Kevin/the Horde's captivity"));
        listMovie.add(new Movie(R.drawable.poster_how_to_train,"How to Train Your Dragon","As the son of a Viking leader on the cusp of manhood, shy Hiccup Horrendous Haddock III faces a rite of passage: he must kill a dragon to prove his warrior mettle. But after downing a feared dragon, he realizes that he no longer wants to destroy it, and instead befriends the beast – which he names Toothless – much to the chagrin of his warrior father"));
        listMovie.add(new Movie(R.drawable.poster_infinity_war,"Avenger Infinity War","As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain."));
        listMovie.add(new Movie(R.drawable.poster_ralph,"Ralph Breaks the Internet","The six years since the first film, Wreck-It Ralph and Vanellope Von Schweetz have stayed best friends, hanging out after work in Litwak's Arcade. One day, Vanellope expresses how bored she has become of Sugar Rush's tracks, so Ralph sneaks into the game and makes a new track for her"));*/





