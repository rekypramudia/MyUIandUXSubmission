package com.latihan.reky.myuianduxsubmission;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Objects;


public class DetailActivityMovie extends AppCompatActivity {

    private ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_movie);

        progressBar = findViewById(R.id.progressBarMovie);

        String imageMovie = Objects.requireNonNull(getIntent().getExtras()).getString("movie_img");
        String titleMovie = getIntent().getExtras().getString("movie_title");
        String descMovie = getIntent().getExtras().getString("movie_desc");

        ImageView imageView = findViewById(R.id.img_movie_detail);
        TextView titleMovieDetail = findViewById(R.id.tv_detail_title_movie);
        TextView descMovieDetail = findViewById(R.id.tv_detail_desc_movie);

        progressBar.setVisibility(View.VISIBLE);

        Picasso.get().load("https://image.tmdb.org/t/p/w780"+ imageMovie)
                .fit().centerInside()
                .into(imageView, new com.squareup.picasso.Callback(){

                    @Override
                    public void onSuccess() {
                        if (progressBar != null) {
                            progressBar.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onError(Exception e) {
                        e.printStackTrace();

                    }
                });
        titleMovieDetail.setText(titleMovie);
        descMovieDetail.setText(descMovie);
    }
}
