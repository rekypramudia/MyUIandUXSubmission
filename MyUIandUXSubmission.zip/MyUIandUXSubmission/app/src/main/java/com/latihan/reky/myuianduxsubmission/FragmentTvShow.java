package com.latihan.reky.myuianduxsubmission;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class FragmentTvShow extends Fragment {

    private RecyclerView rvShow;
    private TvShowViewModel tvShowViewModel;
    private ProgressDialog progressDialog;
    private TvShowAdapter tvShowAdapter;
    public FragmentTvShow() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.tvshow_fragmnet, container, false);
        rvShow = view.findViewById(R.id.tvshow_rv);
        rvShow.setLayoutManager(new LinearLayoutManager(getActivity()));
        progressDialog = new ProgressDialog(requireContext());
        progressDialog.setMessage("Loading....");
        tvShowAdapter = new TvShowAdapter(requireContext(), new ArrayList<TvShow>());
        rvShow.setAdapter(tvShowAdapter);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tvShowViewModel= new ViewModelProvider(this).get(TvShowViewModel.class);
        tvShowViewModel.setData().observe(getViewLifecycleOwner(), new Observer<List<TvShow>>() {
            @Override
            public void onChanged(List<TvShow> shows) {
                tvShowAdapter.setListShow(shows);
            }
        });
        tvShowViewModel.getLoading().observe(getViewLifecycleOwner(), new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                if(aBoolean){
                    progressDialog.show();
                } else {
                    progressDialog.dismiss();
                }
            }
        });
        tvShowViewModel.getDataShow(requireContext());
    }


   /* @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        listShow = new ArrayList<>();
        listShow.add(new TvShow(R.drawable.poster_arrow,"Arrow","Arrow is an American superhero television series developed by Greg Berlanti, Marc Guggenheim, and Andrew Kreisberg based on the DC Comics character Green Arrow, a costumed crime-fighter created by Mort Weisinger and George Papp, and is set in the Arrowverse, sharing continuity with other Arrowverse television series"));
        listShow.add(new TvShow(R.drawable.poster_doom_patrol,"Doom Patrol","Doom Patrol is a superhero team from DC Comics. The original Doom Patrol first appeared in My Greatest Adventure #80 (June 1963),[1] and was created by writers Arnold Drake and Bob Haney, and artist Bruno Premiani. Doom Patrol has appeared in different incarnations in multiple comics, and have been adapted to other media"));
        listShow.add(new TvShow(R.drawable.poster_family_guy,"Family Guy","Family Guy is an American animated sitcom television series created by Seth MacFarlane for the Fox Broadcasting Company. The series centers on the Griffins, a family consisting of parents Peter and Lois; their children, Meg, Chris, and Stewie; and their anthropomorphic pet dog, Brian"));
        listShow.add(new TvShow(R.drawable.poster_flash,"The Flash","The Flash is an American superhero television series developed by Greg Berlanti, Andrew Kreisberg, and Geoff Johns, airing on The CW. It is based on the DC Comics character Barry Allen / Flash, a costumed superhero crime-fighter with the power to move at superhuman speeds. It is a spin-off from Arrow, existing in the same fictional universe."));
        listShow.add(new TvShow(R.drawable.poster_iron_fist,"Iron Fist","Marvel's Iron Fist, or simply Iron Fist, is an American web television series created for Netflix by Scott Buck, based on the Marvel Comics character of the same name. It is set in the Marvel Cinematic Universe (MCU), sharing continuity with the films of the franchise and is the fourth in a series of shows that lead to The Defenders crossover miniseries"));
        listShow.add(new TvShow(R.drawable.poster_naruto_shipudden,"Naruti Shippuden","Naruto (ナルト) is a Japanese manga series written and illustrated by Masashi Kishimoto. It tells the story of Naruto Uzumaki, a young ninja who seeks to gain recognition from his peers and also dreams of becoming the Hokage, the leader of his village. The story is in two parts, the first set in Naruto's pre-teen years, and the second in his teens"));
        listShow.add(new TvShow(R.drawable.poster_ncis,"N C I S","NCIS is an American action police procedural television series, revolving around a fictional team of special agents from the Naval Criminal Investigative Service. The concept and characters were initially introduced in two episodes of the CBS series JAG (season eight episodes 20 and 21: \"Ice Queen\" and \"Meltdown\")."));
        listShow.add(new TvShow(R.drawable.poster_riverdale,"Riverdale","Riverdale is an American teen drama television series based on the characters of Archie Comics. The series was adapted for The CW by Archie Comics' chief creative officer Roberto Aguirre-Sacasa, and is produced by Warner Bros. Television and CBS Television Studios, in association with Berlanti Productions and Archie Comics."));
        listShow.add(new TvShow(R.drawable.poster_the_simpson,"The simpson","The Simpsons is an American animated sitcom created by Matt Groening for the Fox Broadcasting Company.[1][2][3] The series is a satirical depiction of working-class life, epitomized by the Simpson family, which consists of Homer, Marge, Bart, Lisa, and Maggie. The show is set in the fictional town of Springfield and parodies American culture and society, television, and the human condition."));
        listShow.add(new TvShow(R.drawable.poster_the_walking_dead,"The Walking Dead","The Walking Dead is an American post-apocalyptic horror television series for AMC based on the comic book series by Robert Kirkman, Tony Moore, and Charlie Adlard. The series features a large ensemble cast as survivors of a zombie apocalypse, trying to stay alive under near-constant threat of attacks from the mindless zombies, colloquially known as \"walkers\""));

    }*/
}
